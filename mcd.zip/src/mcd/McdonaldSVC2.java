package mcd;

import static mcd.db.DBUtil.close;
import static mcd.db.DBUtil.getConnection;

import java.sql.*;
import java.util.*;
import java.sql.*;
import java.util.Scanner;

public class McdonaldSVC2 {
	
	Connection con;
	
	package mc;

	import static dbc7.db.JdbcUtil.close;
	import static dbc7.db.JdbcUtil.getConnection;

	import java.sql.*;
	import java.util.*;

	import dbc7.BoardVO;

	public class OrderSVC {
	   Connection con;
	   Scanner or = new Scanner(System.in);
	   

	   public  OrderVO getOrderVO(Scanner or) { //주문정보 입력
	      System.out.println("필수정보를 입력해주세요.");

	      String str = or.next();

	      System.out.println("주문하시려면 개인정보를 입력해주세요.");
	      System.out.print("이름 :");
	      String name = or.next();
	      System.out.println("연락처 : ");
	      String phnum = or.next();
	      System.out.println("주소: ");
	      String address = or.next();
	   
	      OrderVO orderVO = new OrderVO();
	      return orderVO;
	   }
	   
	     public void insertOrderInfo(Scanner or) {//주문테이블에 insert
	         OrderVO orderVO = getOrderVO(or);
	         con = getConnection();
	         PreparedStatement pstmt = null;
	         
	         String sql = "INSERT INTO tbl_order(tbl_order_seq.nextval, ?, ?, ?,?,?,?,?,?)"; //
	         try {   pstmt = con.prepareStatement(sql);
	            pstmt.setString(1, orderVO.getName()); 
	            pstmt.setInt(2, orderVO.getPhnum()); 
	            pstmt.setString(3, orderVO.getAddress()); 
	            pstmt.setString(4,orderVO.getOrder_info());
	            pstmt.setInt(5,orderVO.getOrder_count());
	            pstmt.setInt(6,orderVO.getTot_price());
	            pstmt.setDate(7,orderVO.getOrder_time());
	            pstmt.setString(8,orderVO.getCancle_yn());
	            
	            
	            int count = pstmt.executeUpdate();
	            if (count > 0) { System.out.println("주문이 완료 되었습니다"); } 
	            else { System.out.println("주문 취소"); }
	   
	         } catch (Exception e) { e.printStackTrace(); } 
	         finally { close(pstmt); close(con); }
	      }}
	   
	
	
	
	public McdonaldVO getMcdonaldVO(Scanner sc) {
		System.out.println("=== 상품 등록 ===");
		System.out.print("상품번호 : ");
			int prod_num = sc.nextInt();
		System.out.print("상품명 : ");
			String prod_name = sc.next();
		System.out.print("상품가격 : ");
			int price = sc.nextInt(); 
		System.out.print("상품정보 : ");
			String prod_info = sc.next(); 
		System.out.print("상품종류 : ");
			String value = sc.next(); 	
		
		McdonaldVO mcdonaldVO = new McdonaldVO(prod_num, prod_name, price, prod_info, value);
		return mcdonaldVO;
	}
	
	public void addItem(Scanner sc) throws SQLException {
		McdonaldVO mcdVO = getMcdonaldVO(sc);
		getConnection();
		PreparedStatement ps = null;
		String sql = "insert into tbl_burger values (?, ?, ?, ?, ?)";

		try {
		ps = con.prepareStatement(sql);
		ps.setInt(1, mcdVO.getItemId());
		ps.setString(2, mcdVO.getItemName());
		ps.setInt(3, mcdVO.getPrice());
		ps.setString(4, mcdVO.getItemInfo());
		ps.setString(5, mcdVO.getItemType());

		int count = ps.executeUpdate();
		
		getIngreVO(sc);
		
		if (count>0) {
			System.out.println("상품 등록 완료");
		} else 
			System.out.println("상품 등록 실패");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("에러1");
		} finally {
			ps.close();
			con.close();
		}
	}
	
	public void showItem() throws SQLException {
		getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM tbl_burger";
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			System.out.println("\t 상품번호 \t 상품명");
			while (rs.next()) {
				System.out.println(
				"\t" + rs.getInt("prod_num") 
				+ "\t"+ rs.getString("prod_name") 
				);
			}	
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("에러3");
		} finally {
			rs.close();
			ps.close();
			con.close();
		}
	}	
	
	private McdonaldVO getMcdonaldItemId(int prod_num) throws SQLException {
		McdonaldVO mcdonaldVO = null;
		getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM tbl_burger WHERE prod_num = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, prod_num);
			rs = ps.executeQuery();
			if (rs.next()) {
				int dbId = rs.getInt("prod_num");
				String prod_name = rs.getString("prod_name");
				int price = rs.getInt("price");
				String prod_info = rs.getString("prod_info");
				String value = rs.getString("value");
				mcdonaldVO = new McdonaldVO(dbId, prod_name, price, prod_info, value);
			}
			
			System.out.println(mcdonaldVO);

			showIngreVO(prod_num); 			// 영양정보 가져오기
			
						
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			rs.close();
			ps.close();
			con.close();
		}
		return mcdonaldVO;
	}
		
		
	public void updateItem(Scanner sc) throws SQLException {

		showItem();

		System.out.println("수정할 상품의 상품번호를 입력하세요.");
		System.out.print("상품번호 : ");
		int prod_num = sc.nextInt();
		
		McdonaldVO mcdonaldVO = getMcdonaldItemId(prod_num);
		
		System.out.println("수정할 데이터를 입력하세요.");
		System.out.println("원래 상품명 : " + mcdonaldVO.getItemName());
		System.out.print("수정할 상품명 : ");
		String prod_name = sc.next();

		System.out.println("원래 상품가격 : " + mcdonaldVO.getPrice());
		System.out.print("수정할 상품가격 : ");
		int price = sc.nextInt();

		System.out.println("원래 상품정보 : " + mcdonaldVO.getItemInfo());
		System.out.print("수정할 상품정보 : ");
		String prod_info = sc.next();

		System.out.println("원래 상품종류 : " + mcdonaldVO.getItemType());
		System.out.print("수정할 상품종류 : ");
		String value = sc.next();

		mcdonaldVO.setItemName(prod_name);
		mcdonaldVO.setPrice(price);
		mcdonaldVO.setItemInfo(prod_info);
		mcdonaldVO.setItemType(value);

		int count = updateItem(mcdonaldVO);
		
		getIngreVO(sc);
		
		if (count > 0) {
			System.out.println("상품 수정 완료");
		} else {
			System.out.println("상품 수정 실패");
		}
		
	}
	
	private int updateItem(McdonaldVO mcdonaldVO) throws SQLException {
		int updateCount = 0;
		getConnection();
		PreparedStatement ps = null;

		String sql = "UPDATE tbl_burger SET prod_name = ?, price = ?, prod_info = ?, value = ?"
				+ " WHERE prod_num = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, mcdonaldVO.getItemName());
			ps.setInt(2, mcdonaldVO.getPrice());
			ps.setString(3, mcdonaldVO.getItemInfo());
			ps.setString(4, mcdonaldVO.getItemType());
			ps.setInt(5, mcdonaldVO.getItemId());
			updateCount = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ps.close();
			con.close();
		}
		return updateCount;
	}
	
	
	public void deleteItem(Scanner sc) throws SQLException {
		System.out.println("삭제할 상품번호를 입력하세요.");
		System.out.print("상품번호 : ");
		int id = sc.nextInt();

		int count = deleteItem(id);
		deleteIngre(id);
		
		if (count > 0) {
			System.out.println("상품 삭제 완료");
		} else {
			System.out.println("상품 삭제 실패");
		}
	}
	
	public int deleteItem(int prod_num) throws SQLException {
		int deleteCount = 0;
		getConnection();
		PreparedStatement ps = null;

		String sql = "DELETE tbl_burger WHERE prod_num = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, prod_num);
			deleteCount = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ps.close();
			con.close();
		}
		return deleteCount;
	}
	
	public int deleteIngre(int id) {
		getConnection();
		PreparedStatement ps = null;
		String sql = "DELETE TBL_INGREDIENT WHERE PROD_NUM = ?";
		
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
			
//			System.out.println("영양정보삭제완료");
			ps.close();
		} catch(Exception e) { 
			System.out.println("영양정보삭제오류");
			e.printStackTrace(); }
		return id; 
	}
	
	
	public IngreVO showIngreVO(int num) {	
		IngreVO ingreVO = null;
		getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM TBL_INGREDIENT WHERE product_num = ?";
			
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);			
			rs = pstmt.executeQuery();
			if ( rs.next() ) {					
				int p_num = rs.getInt("p_num");
				int gram = rs.getInt("gram");
				int ml = rs.getInt("ml");
				int kcal = rs.getInt("kcal");
				int sugar = rs.getInt("sugar");
				int protein = rs.getInt("protein");
				int fat = rs.getInt("fat");
				int natrium = rs.getInt("natrium");
				int caffeine = rs.getInt("caffeine");
				ingreVO = new IngreVO(p_num, gram, ml, kcal, sugar, protein, fat, natrium, caffeine);
			}
			
			System.out.println(ingreVO);
				
		} catch(Exception e) {
			System.out.println("에러발생"); 			e.printStackTrace();
		} finally {
			close(rs); 			close(pstmt);			close(con);
		} return ingreVO;
	}
		
	public IngreVO getIngreVO(Scanner sc) {
		getConnection();
		PreparedStatement pstmt = null;
		
		System.out.println("영양정보를 변경합니다.");
		System.out.println("상품번호를 입력해주세요");
		int p_num = Integer.parseInt(sc.next());
		
		System.out.println("중량(g)을 입력해주세요");
		int gram = Integer.parseInt(sc.next());

		System.out.println("중량(ml)을 입력해주세요");
		int ml = Integer.parseInt(sc.next());
		
		System.out.println("열량을 입력해주세요");
		int kcal = Integer.parseInt(sc.next());
		
		System.out.println("당을 입력해주세요");
		int sugar = Integer.parseInt(sc.next());
		
		System.out.println("단백질을 입력해주세요");
		int protein = Integer.parseInt(sc.next());
		
		System.out.println("포화지방을 입력해주세요");
		int fat = Integer.parseInt(sc.next());
		
		System.out.println("나트륨을 입력해주세요");
		int natrium = Integer.parseInt(sc.next());
			
		System.out.println("카페인을 입력해주세요");
		int caffeine = Integer.parseInt(sc.next());
	
		IngreVO ingreVO = new IngreVO(p_num, gram, ml, kcal, sugar, protein, fat, natrium, caffeine);
		return ingreVO;
	} 

	public void insertIngreVO(Scanner sc) {
		IngreVO ingreVO = getIngreVO(sc);
		getConnection();
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO TBL_INGREDIENT VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, ingreVO.getGram());
			pstmt.setInt(2, ingreVO.getGram());
			pstmt.setInt(3, ingreVO.getMl());
			pstmt.setInt(4, ingreVO.getKcal());
			pstmt.setInt(5, ingreVO.getSugar());
			pstmt.setInt(6, ingreVO.getProtein());
			pstmt.setInt(7, ingreVO.getFat());
			pstmt.setInt(8, ingreVO.getNatrium());
			pstmt.setInt(8, ingreVO.getCaffeine());
				
			int count = pstmt.executeUpdate();
			if (count > 0 ) {
				System.out.println(" 영양정보 등록을 완료하였습니다 ");
			} else { System.out.println("영양정보 등록을 실패하였습니다. "); }
		} catch(Exception e) {e.printStackTrace();
		} finally {
			 try{pstmt.close(); con.close();}
			 catch (SQLException se) {}
		}
	}
	
	public void getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "test";
			String pw = "1111";
			con = DriverManager.getConnection(url, user, pw);
			con.setAutoCommit(false);
		} catch (Exception e){
			e.printStackTrace();
			System.out.println("에러2");
		}
	}
}


package mcd;

import static mcd.db.DBUtil.*;

import java.sql.*;
import java.util.*;
import java.sql.*;
import java.util.Scanner;

public class CustomerSVC {
   
	Connection con;

	//메뉴선택
	public void menuSelect (Scanner sc) {
		//객체받기
		System.out.println("원하시는 상품을 선택하세요.");
		System.out.print("상품번호 : ");
		int prod_num = sc.nextInt();
		
	}
	
	//메뉴
	public void orderItem(int prod_num) throws SQLException {
		con = getConnection();
		PreparedStatement ps = null;

		String sql = "select * from tbl_burger union select * from tbl_desert WHERE prod_num = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, prod_num);
			ps.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ps.close();
			con.close();
		}
	}
	
   }
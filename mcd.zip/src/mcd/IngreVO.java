package mcd;

public class IngreVO {
	private int p_num; //  상품번호 
	private int gram; //	중량(G)
	private int ml; //	중량(ML)
	private int kcal; //	열량
	private int sugar; //	당
	private int protein; //	단백질
	private int fat; //	포화지방
	private int natrium; //	나트륨
	private int caffeine; //	카페인
		
	public IngreVO(int p_num, int gram, int ml, int kcal, int sugar, int protein, int fat, int natrium, int caffeine) {
		super();
		this.p_num = p_num;
		this.gram = gram;
		this.ml = ml;
		this.kcal = kcal;
		this.sugar = sugar;
		this.protein = protein;
		this.fat = fat;
		this.natrium = natrium;
		this.caffeine = caffeine;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public int getGram() {
		return gram;
	}
	public void setGram(int gram) {
		this.gram = gram;
	}
	public int getMl() {
		return ml;
	}
	public void setMl(int ml) {
		this.ml = ml;
	}
	public int getKcal() {
		return kcal;
	}
	public void setKcal(int kcal) {
		this.kcal = kcal;
	}
	public int getSugar() {
		return sugar;
	}
	public void setSugar(int sugar) {
		this.sugar = sugar;
	}
	public int getProtein() {
		return protein;
	}
	public void setProtein(int protein) {
		this.protein = protein;
	}
	public int getFat() {
		return fat;
	}
	public void setFat(int fat) {
		this.fat = fat;
	}
	public int getNatrium() {
		return natrium;
	}
	public void setNatrium(int natrium) {
		this.natrium = natrium;
	}
	public int getCaffeine() {
		return caffeine;
	}
	public void setCaffeine(int caffeine) {
		this.caffeine = caffeine;
	}
	
	@Override
	public String toString() {
		return " 영양정보\n 중량(g)\t 중량(ml) 열량 \t 당\t단백질\t포화지방\t나트륨\t카페인 \n" +
				"===============================================================\n"
				+ " " + gram + " \t "+ ml+ " \t " + kcal+ " \t " + sugar	+ " \t "+ protein 
				+ " \t "+ fat+ " \t " + natrium + " \t "+ caffeine;
	}
}
